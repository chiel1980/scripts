"""
builder.py
----------
Renders the cleaned, structured content (from content_cache.json) into a
static, responsive, dark-themed HTML site using Jinja2 templates.

The whole site is re-rendered every run (it's cheap and keeps templates
and re-themes in sync everywhere); only the *scraping/downloading* step
upstream is incremental.
"""
from __future__ import annotations

import re
import shutil
from datetime import datetime
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape

from .assets import ensure_image
from .scraper import Fetcher, slug_from_url

ROOT = Path(__file__).resolve().parent.parent
TEMPLATES_DIR = ROOT / "templates"
STATIC_DIR = ROOT / "static"

LINK_PATTERN = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")


def linkify(text: str) -> str:
    """Turns our internal [label](url) markers into safe <a> tags.
    Runs *after* Jinja's autoescaping by being marked safe at call sites
    that already escaped the surrounding text manually."""
    from markupsafe import Markup, escape

    out = []
    pos = 0
    for m in LINK_PATTERN.finditer(text):
        out.append(escape(text[pos : m.start()]))
        label, href = m.group(1), m.group(2)
        external = href.startswith("http") and "thatspecificsound" not in href
        rel = ' rel="noopener noreferrer" target="_blank"' if external else ""
        out.append(Markup(f'<a href="{escape(href)}"{rel}>{escape(label)}</a>'))
        pos = m.end()
    out.append(escape(text[pos:]))
    return Markup("").join(out)


def get_env() -> Environment:
    env = Environment(
        loader=FileSystemLoader(str(TEMPLATES_DIR)),
        autoescape=select_autoescape(["html"]),
        trim_blocks=True,
        lstrip_blocks=True,
    )
    env.filters["linkify"] = linkify
    return env


def build_site(state, output_dir: Path, fetcher: Fetcher) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    env = get_env()
    images_dir = output_dir / "assets" / "images"

    pages = state.content_cache  # url -> parsed dict
    home = next((p for p in pages.values() if p.get("type") == "home"), None)
    about = next((p for p in pages.values() if p.get("type") == "about"), None)
    interviews_index = next((p for p in pages.values() if p.get("type") == "interviews_index"), None)
    interviews = sorted(
        (p for p in pages.values() if p.get("type") == "interview"),
        key=lambda p: p.get("title", ""),
    )

    for iv in interviews:
        iv["slug"] = slug_from_url(iv["url"])
        iv["hero_image_local"] = ensure_image(iv.get("hero_image"), images_dir, fetcher)

    nav = [
        {"label": "Home", "href": "index.html"},
        {"label": "Interviews", "href": "interviews/index.html"},
        {"label": "About", "href": "about.html"},
        {"label": "Changes", "href": "changes.html"},
    ]

    common = {
        "nav": nav,
        "site_title": "That Specific Sound",
        "site_tagline": (home or {}).get(
            "tagline",
            "The gear and rigs behind hardcore and metal's most distinctive guitar tones.",
        ),
        "generated_at": datetime.now().strftime("%-d %B %Y"),
    }

    # ---- home ----
    (output_dir / "index.html").write_text(
        env.get_template("home.html").render(
            **common, page=home or {}, interviews=interviews[:6], active="Home"
        ),
        encoding="utf-8",
    )

    # ---- about ----
    if about:
        (output_dir / "about.html").write_text(
            env.get_template("about.html").render(**common, page=about, active="About"),
            encoding="utf-8",
        )

    # ---- interviews index ----
    interviews_dir = output_dir / "interviews"
    interviews_dir.mkdir(exist_ok=True)
    (interviews_dir / "index.html").write_text(
        env.get_template("interviews.html").render(
            **common,
            page=interviews_index or {},
            interviews=interviews,
            active="Interviews",
            path_prefix="../",
        ),
        encoding="utf-8",
    )

    # ---- individual interviews ----
    for iv in interviews:
        (interviews_dir / f"{iv['slug']}.html").write_text(
            env.get_template("interview.html").render(
                **common, page=iv, active="Interviews", path_prefix="../"
            ),
            encoding="utf-8",
        )

    # ---- changelog page ----
    (output_dir / "changes.html").write_text(
        env.get_template("changes.html").render(
            **common, changelog=list(reversed(state.changelog)), active="Changes"
        ),
        encoding="utf-8",
    )

    # ---- static assets (css/js) ----
    out_static = output_dir / "static"
    if out_static.exists():
        shutil.rmtree(out_static)
    shutil.copytree(STATIC_DIR, out_static)
