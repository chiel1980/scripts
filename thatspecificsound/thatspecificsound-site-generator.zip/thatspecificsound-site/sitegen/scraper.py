"""
scraper.py
----------
Fetches pages from the source WordPress.com site and parses the
"Archivist" theme markup into plain structured data (dicts / lists of
strings), with no WordPress- or Facebook-specific markup surviving.

Networking uses conditional GET (If-None-Match / If-Modified-Since) so
that re-running the script does not re-download pages that have not
changed on the source since the last run.
"""
from __future__ import annotations

import hashlib
import re
import time
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup, NavigableString, Tag

BASE_URL = "https://thatspecificsound.wordpress.com"
USER_AGENT = (
    "ThatSpecificSoundArchiver/1.0 "
    "(+static site generator; respectful crawl, low frequency)"
)
REQUEST_DELAY = 1.0  # seconds between requests, be polite to the source site


def content_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


class Fetcher:
    """Thin wrapper around requests with conditional GET + rate limiting."""

    def __init__(self, delay: float = REQUEST_DELAY):
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": USER_AGENT})
        self.delay = delay
        self._last_request = 0.0

    def _throttle(self):
        elapsed = time.time() - self._last_request
        if elapsed < self.delay:
            time.sleep(self.delay - elapsed)

    def get(self, url: str, cache_headers: dict | None = None, timeout: int = 20):
        """Returns (status, html, new_cache_headers).
        status is one of: 'new', 'unchanged', 'error'
        """
        headers = {}
        if cache_headers:
            if cache_headers.get("etag"):
                headers["If-None-Match"] = cache_headers["etag"]
            if cache_headers.get("last_modified"):
                headers["If-Modified-Since"] = cache_headers["last_modified"]

        self._throttle()
        try:
            resp = self.session.get(url, headers=headers, timeout=timeout)
        except requests.RequestException as exc:
            return "error", None, cache_headers or {}, str(exc)
        finally:
            self._last_request = time.time()

        if resp.status_code == 304:
            return "unchanged", None, cache_headers or {}, None
        if resp.status_code != 200:
            return "error", None, cache_headers or {}, f"HTTP {resp.status_code}"

        new_cache = {
            "etag": resp.headers.get("ETag"),
            "last_modified": resp.headers.get("Last-Modified"),
        }
        return "new", resp.text, new_cache, None

    def download_binary(self, url: str, timeout: int = 30) -> bytes | None:
        self._throttle()
        try:
            resp = self.session.get(url, timeout=timeout)
            self._last_request = time.time()
            if resp.status_code == 200:
                return resp.content
        except requests.RequestException:
            pass
        return None


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------

# Anything under these hosts/paths is WordPress.com or Facebook plumbing
# and must never survive into the generated site.
# Anything under these hosts/paths is WordPress.com or Facebook plumbing
# and must never survive into the generated site. The source site itself
# (thatspecificsound.wordpress.com) is *not* blocked - those are normal
# internal links we want to keep (rewritten to local pages later).
BLOCKED_HOSTS = (
    "wordpress.com",
    "wp.me",
    "facebook.com",
    "automattic.com",
    "gravatar.com",
    "pixel.wp.com",
    "stats.wp.com",
    "jetpack.com",
)
SOURCE_HOST = urlparse(BASE_URL).netloc  # thatspecificsound.wordpress.com


def is_blocked_url(url: str) -> bool:
    if not url:
        return False
    host = urlparse(url, scheme="https").netloc
    if not host:
        # relative URL (e.g. "#") - never blocked, handled elsewhere
        return False
    if host == SOURCE_HOST:
        return False
    return any(host == h or host.endswith("." + h) for h in BLOCKED_HOSTS)


def find_main_content(soup: BeautifulSoup) -> Tag | None:
    """Locate the WordPress 'Archivist' theme's article body."""
    for selector in (
        "article .entry-content",
        ".entry-content",
        "article",
        "main",
    ):
        node = soup.select_one(selector)
        if node:
            return node
    return None


def page_title(soup: BeautifulSoup) -> str:
    h1 = soup.select_one("article h1.entry-title") or soup.select_one("h1")
    if h1:
        return clean_text(h1.get_text(" ", strip=True))
    if soup.title:
        return clean_text(soup.title.get_text().split("–")[0])
    return "Untitled"


def clean_text(text: str) -> str:
    text = text.replace("\xa0", " ")
    text = re.sub(r"\s+", " ", text).strip()
    return text


def slug_from_url(url: str) -> str:
    path = urlparse(url).path.strip("/")
    return path.split("/")[-1] if path else "index"


def absolutize(url: str | None) -> str | None:
    if not url:
        return None
    return urljoin(BASE_URL, url)


def strip_wp_chrome(node: Tag) -> None:
    """Remove WordPress/Facebook navigation, tracking and marketing chrome
    from a parsed content node, in place."""
    if node is None:
        return

    # Remove elements linking to blocked hosts (sign up / log in / report /
    # subscribe / "Blog at WordPress.com" / Facebook publisher links, etc).
    for a in node.find_all("a", href=True):
        if is_blocked_url(a["href"]):
            # If the link is the only thing in its parent <p>/<li>, drop the
            # whole parent; otherwise just unwrap the anchor.
            parent = a.parent
            if parent and parent.name in ("p", "li") and parent.get_text(strip=True) == a.get_text(strip=True):
                parent.decompose()
            else:
                a.decompose()

    # Tracking pixels / blavatar images
    for img in node.find_all("img", src=True):
        if is_blocked_url(img["src"]):
            img.decompose()

    # Comment forms / "Loading Comments" / login-to-comment widgets
    for el in node.select("#comments, .comments-area, .jetpack-comment-likes"):
        el.decompose()


# ---------------------------------------------------------------------------
# Page-specific parsers -> plain dict output (no soup objects survive)
# ---------------------------------------------------------------------------

def parse_home(html: str) -> dict:
    soup = BeautifulSoup(html, "html.parser")
    content = find_main_content(soup)
    strip_wp_chrome(content)

    tagline_el = soup.select_one(".site-description, .tagline")
    tagline = clean_text(tagline_el.get_text(" ", strip=True)) if tagline_el else ""

    paragraphs = []
    links = {}
    if content:
        for p in content.find_all("p"):
            txt = clean_text(p.get_text(" ", strip=True))
            if not txt:
                continue
            paragraphs.append(txt)
        for a in content.find_all("a", href=True):
            href = absolutize(a["href"])
            if href and href.startswith(BASE_URL):
                label = clean_text(a.get_text(" ", strip=True))
                if label:
                    links[label] = href

    return {
        "type": "home",
        "title": "That Specific Sound",
        "tagline": tagline,
        "paragraphs": paragraphs,
        "links": links,
    }


def parse_about(html: str) -> dict:
    soup = BeautifulSoup(html, "html.parser")
    content = find_main_content(soup)
    strip_wp_chrome(content)
    title = page_title(soup)

    paragraphs = []
    if content:
        for p in content.find_all("p"):
            txt = clean_text(p.get_text(" ", strip=True))
            if txt:
                paragraphs.append(txt)

    return {"type": "about", "title": title, "paragraphs": paragraphs}


def parse_interviews_index(html: str) -> dict:
    soup = BeautifulSoup(html, "html.parser")
    content = find_main_content(soup)
    strip_wp_chrome(content)
    title = page_title(soup)

    intro = []
    entries = []
    if content:
        for el in content.children:
            if isinstance(el, NavigableString):
                continue
            if el.name == "ul":
                for li in el.find_all("li", recursive=False):
                    a = li.find("a", href=True)
                    if a:
                        entries.append(
                            {
                                "title": clean_text(a.get_text(" ", strip=True)).lstrip("\u2013- "),
                                "url": absolutize(a["href"]),
                            }
                        )
            elif el.name == "p":
                txt = clean_text(el.get_text(" ", strip=True))
                a = el.find("a", href=True)
                if a and txt.lstrip("\u2013- ").startswith(clean_text(a.get_text(" ", strip=True))):
                    entries.append(
                        {
                            "title": clean_text(a.get_text(" ", strip=True)),
                            "url": absolutize(a["href"]),
                        }
                    )
                elif txt:
                    intro.append(txt)

    return {"type": "interviews_index", "title": title, "intro": intro, "entries": entries}


def parse_interview(html: str, url: str) -> dict:
    soup = BeautifulSoup(html, "html.parser")
    content = find_main_content(soup)
    strip_wp_chrome(content)
    title = page_title(soup)

    hero_image = None
    og_image = soup.select_one('meta[property="og:image"]')
    if og_image and og_image.get("content") and not is_blocked_url(og_image["content"]):
        hero_image = absolutize(og_image["content"])

    blocks: list[dict] = []
    photo_credit = None
    outro: list[dict] = []  # paragraphs after the Q&A, often with external links

    if content:
        first_img = content.find("img")
        if first_img and first_img.get("src") and not is_blocked_url(first_img["src"]):
            hero_image = absolutize(first_img["src"])

        children = [c for c in content.children if isinstance(c, Tag)]
        in_outro = False
        for el in children:
            if el.name == "img":
                continue

            if el.name == "p":
                strong = el.find("strong")
                em = el.find("em")
                text = clean_text(el.get_text(" ", strip=True))
                if not text:
                    continue

                is_question = bool(strong) and clean_text(strong.get_text(" ", strip=True)) == text
                is_photo_credit = text.lower().startswith("photo credit")

                if is_photo_credit:
                    photo_credit = strip_inline_links(el)
                    continue

                if is_question:
                    blocks.append({"kind": "question", "text": text})
                    continue

                # Headings like "## The Archivist Theme" footer junk already
                # removed by strip_wp_chrome; treat short italic-only closing
                # paragraphs with links as the outro / credits section.
                if em and clean_text(em.get_text(" ", strip=True)) == text:
                    outro.append({"text": strip_inline_links(el)})
                    continue

                blocks.append({"kind": "answer", "text": text})

            elif el.name == "ul":
                items = [clean_text(li.get_text(" ", strip=True)) for li in el.find_all("li", recursive=False)]
                items = [i for i in items if i]
                if items:
                    blocks.append({"kind": "list", "list_items": items})

            elif el.name == "h2":
                # Theme footer heading ("The Archivist Theme") - everything
                # from here on is WordPress chrome, stop processing.
                break

    # Group the flat block list into question/answer units so the template
    # can render each Q&A as a single unit instead of walking a flat list.
    qa: list[dict] = []
    intro: list[dict] = []
    current = None
    for b in blocks:
        if b["kind"] == "question":
            current = {"question": b["text"], "answers": []}
            qa.append(current)
        elif current is None:
            intro.append(b)
        else:
            current["answers"].append(b)

    return {
        "type": "interview",
        "title": title,
        "url": url,
        "hero_image": hero_image,
        "photo_credit": photo_credit,
        "intro": intro,
        "qa": qa,
        "outro": outro,
    }


def strip_inline_links(el: Tag) -> str:
    """Render an element's text with [label](href) markers preserved as
    a simple list the template can turn into real <a> tags, while
    dropping any blocked (WP/FB) links and emoji tracking images. Walks
    the full subtree so links nested inside <em>/<strong> etc. survive."""

    def walk(node) -> str:
        if isinstance(node, NavigableString):
            return str(node)
        if not isinstance(node, Tag):
            return ""
        if node.name == "a" and node.get("href"):
            href = node["href"]
            if is_blocked_url(href):
                return node.get_text(" ", strip=True)
            label = node.get_text(" ", strip=True)
            return f"[{label}]({absolutize(href)})"
        if node.name == "img":
            alt = node.get("alt", "")
            if alt and not is_blocked_url(node.get("src", "")):
                return alt
            return ""
        return "".join(walk(child) for child in node.children)

    return clean_text(walk(el))
